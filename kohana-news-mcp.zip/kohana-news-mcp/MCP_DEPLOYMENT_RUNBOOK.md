# Runbook — Deploy the Kohana News MCP as its own remote MCP server (ACA + Entra → Foundry Toolbox v2)

**Scope:** stand up `kohana-news-mcp` (paid‑news tools: Green Street + IPE) as a **standalone remote MCP server** on **Azure Container Apps**, secured with an **Entra app registration** whose app role is granted to the **Foundry project managed identity**, then register it into the existing `kohana-mi-tools` **Toolbox as a new version (v2)** next to `web_search` and **promote it with no agent redeploy**. Companion to `AGENT_DEPLOYMENT_RUNBOOK.md` (M1 agent); same project `joserodr72t-8090`, same region as the project (`westus` for the demo, EU for Kohana's tenant). Substitute your own values.

> Verified against Microsoft Foundry / Azure MCP docs as of **July 2026**. Foundry's MCP surface moves fast; the doc‑verified facts are marked **[docs]**, and the two things you must confirm on first run are marked **[confirm on run]**. Re‑check the *What's new* page before you start.

---

## The single most important lesson (it mirrors the agent runbook)

Foundry does **not** host an arbitrary custom MCP server inside its runtime the way it hosts agents. **[docs]** The Agent Service runtime only accepts a *remote MCP endpoint*; a custom server must be self‑hosted (Azure Container Apps or Azure Functions) to obtain that endpoint. So — exactly as with the agent — **you do not hand‑maintain the deployment plumbing.** You own the server source and its Dockerfile; the ACA environment, the Entra app registration, the project‑MI role assignment, Key Vault access, and App Insights are **scaffolded as bicep** (adapted from the `azmcp-foundry-aca-mi` template) and applied by `azd`. The earlier `scripts/deploy.sh` (hand‑rolled `az containerapp create`, **public open ingress, no Entra**) is what we are replacing.

For a Python FastMCP container on ACA the platform requires: HTTP POST/GET endpoints, a **Linux `linux/amd64`** image, no privileged containers, and **stateless operation**. **[docs]** That last one is a real code change (see §4).

---

## 0. What you own vs. what gets scaffolded

**You own (the mi‑agent‑clean discipline — keep only these in git):**

```
src/server.py        FastMCP server (edit: stateless_http, mount auth middleware)
src/config.py        env-driven settings (add tenant/app-id/audience vars)
src/greenstreet.py   GSN client — unchanged
src/ipe.py           IPE RSS client — unchanged
src/auth.py          NEW: Entra bearer-token validation middleware
Dockerfile           python:3.13-slim, linux/amd64
mcp-toolbox-v2.yaml  Toolbox v2 registration (web_search + this MCP as type: mcp)
INIT.md / README.md  regenerate-per-project instructions
```

**Scaffolded per target project (gitignored — regenerated for demo, then Kohana tenant):**

```
azure.yaml           azd service definition (host: containerapp)
infra/               bicep: aca + entra-app + project-MI role assignment + KV + App Insights
.azure/  .env  environment.sh
```

The infra bicep is **not** hand‑authored. It is lifted from the `azmcp-foundry-aca-mi` module set — `main.bicep`, `aca-infrastructure.bicep`, `entra-app.bicep`, `aif-role-assignment-entraapp.bicep`, `application-insights.bicep` — with the **container image swapped** from Microsoft's Azure‑MCP image to our Python image, and the storage role modules dropped (we don't touch Azure Storage). **[confirm on run]** that template's module names/params against the current version when you clone it.

---

## 1. Prerequisites (Cloud Shell)

Same base as the agent runbook, plus Docker‑less container build via ACR.

```bash
# azd >= 1.27 into ~/.local (Cloud Shell ships too old — see agent runbook §1a)
curl -fsSL https://aka.ms/install-azd.sh | bash -s -- \
  --install-folder ~/.local/azd --symlink-folder ~/.local/bin
export PATH="$HOME/.local/bin:$PATH"; hash -r
azd version                              # >= 1.27.0

az login
az account show --query '{sub:id,tenant:tenantId}' -o table
```

**Roles you need** (superset of the agent deploy):
- **Contributor** (or Owner) on the target resource group — create ACA, ACR, Key Vault, App Insights.
- **Application Administrator** (or Cloud Application Administrator) in Entra — create the app registration + app role and grant admin consent. **[docs]** If you lack this, an Entra admin must run §5a.
- **Azure AI Administrator / Foundry Project Manager** on the project — create the toolbox version and the MCP connection.

---

## 2. Gather identifiers

```bash
RG=rg-joserodr72t-8090
ACCT=joserodr72t-8090-resource
PROJ=joserodr72t-8090
LOC=westus                                   # co-locate MCP with the project

# Foundry project resource id and its managed-identity principal id:
PROJECT_ID=$(az resource show -g "$RG" \
  --namespace Microsoft.CognitiveServices \
  --parent accounts/"$ACCT" --resource-type projects -n "$PROJ" \
  --query id -o tsv)

# The project's system-assigned managed identity principal (the caller we must trust).
# The account holds the identity; confirm the exact path on run.  [confirm on run]
PROJECT_MI_OID=$(az resource show --ids "$PROJECT_ID" \
  --query identity.principalId -o tsv)
echo "$PROJECT_ID"; echo "$PROJECT_MI_OID"

TENANT_ID=$(az account show --query tenantId -o tsv)
```

If `PROJECT_MI_OID` is empty, the identity may live on the account (`$ACCT`) rather than the project, or be user‑assigned — check `az resource show --ids "$PROJECT_ID" --query identity` and the account. **[confirm on run]** This principal is what §5b grants the app role to.

---

## 3. Reshape the repo to the mi‑agent‑clean structure

Delete the hand‑rolled deploy from the old repo; keep source + Dockerfile + the toolbox registration.

```bash
cd kohana-news-mcp
git rm scripts/deploy.sh                      # replaced by azd + infra bicep
# keep scripts/smoke.sh (still useful for the raw MCP handshake in §8)
```

Add the scaffold from the ACA MCP template (for the infra modules only):

```bash
azd init --template azmcp-foundry-aca-mi -e kohana-news-mcp-dev   # [confirm on run] template id
# This lands azure.yaml + infra/. We overwrite the app source with ours (next steps),
# and point azure.yaml's service at OUR Dockerfile / src.
```

> **Bump (expected):** the template's default service builds Microsoft's Azure‑MCP (.NET) image. Edit `azure.yaml` so the `containerapp` service `project:` points at `.` (our repo root) and `docker.path: ./Dockerfile`. Remove the storage‑role bicep module and its `storageAccountId` param from `infra/main.bicep` — we don't grant Storage roles.

---

## 4. Server code adaptations (the three real fixes)

### 4a. Stateless HTTP — required for scale‑to‑zero / multi‑replica **[docs]**

In `src/server.py`, construct FastMCP in stateless mode so no session pins to a replica:

```python
mcp = FastMCP(
    name="kohana-news",
    instructions=(...),                 # unchanged
    host=settings.host,
    port=settings.port,
    streamable_http_path=settings.mcp_path,
    stateless_http=True,                # NEW — ACA MCP hosting is stateless-only
    json_response=True,                 # NEW — plain JSON responses, no SSE session
)
```

### 4b. Pin Python 3.13 + `linux/amd64` (align with the agent; ACA requires amd64) **[docs]**

```dockerfile
# Dockerfile
FROM --platform=linux/amd64 python:3.13-slim
WORKDIR /app
ENV PYTHONUNBUFFERED=1 PIP_NO_CACHE_DIR=1 MCP_PORT=8080
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY src/ ./src/
WORKDIR /app/src
EXPOSE 8080
CMD ["python", "server.py"]
```

Build always targets amd64 (Cloud Shell/ACR handles this): `az acr build --platform linux/amd64 ...`.

### 4c. Entra bearer‑token validation middleware (NEW `src/auth.py`)

The chosen auth model: the agent (via the toolbox/project MI) presents an Entra access token; our server validates it. Validate **issuer**, **audience = `api://<APP_CLIENT_ID>`**, signature (JWKS), and that the `roles` claim contains **`Mcp.Tools.ReadWrite.All`**. Reject otherwise with 401. Mount it as ASGI middleware around the FastMCP app, and **exempt `GET /healthz`** so the ACA probe stays anonymous.

```python
# src/auth.py  (sketch — pin exact issuer/JWKS on first run)  [confirm on run]
import time, httpx
from jose import jwt                          # add python-jose[cryptography] to requirements
from starlette.responses import JSONResponse

class EntraAuthMiddleware:
    def __init__(self, app, tenant_id, audience, required_role, exempt_paths):
        self.app = app
        self.audience = audience
        self.required_role = required_role
        self.exempt = set(exempt_paths)
        self.issuer = f"https://login.microsoftonline.com/{tenant_id}/v2.0"
        self.jwks_uri = f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"
        self._jwks = None; self._jwks_exp = 0

    async def _keys(self):
        if not self._jwks or time.time() > self._jwks_exp:
            async with httpx.AsyncClient(timeout=10) as c:
                self._jwks = (await c.get(self.jwks_uri)).json()
            self._jwks_exp = time.time() + 3600
        return self._jwks

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("path") in self.exempt:
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers") or [])
        auth = headers.get(b"authorization", b"").decode()
        try:
            token = auth.split(" ", 1)[1]
            claims = jwt.decode(
                token, await self._keys(), algorithms=["RS256"],
                audience=self.audience, issuer=self.issuer,
            )
            if self.required_role not in (claims.get("roles") or []):
                raise ValueError("missing app role")
        except Exception as exc:
            resp = JSONResponse({"error": f"unauthorized: {exc}"}, status_code=401)
            return await resp(scope, receive, send)
        return await self.app(scope, receive, send)
```

Wire it in `create_app()`:

```python
def create_app():
    app = mcp.streamable_http_app()
    # ... existing /healthz route append ...
    if settings.entra_auth_enabled:            # off locally, on in ACA
        from auth import EntraAuthMiddleware
        return EntraAuthMiddleware(
            app, tenant_id=settings.tenant_id,
            audience=settings.app_audience,                 # api://<APP_CLIENT_ID>
            required_role="Mcp.Tools.ReadWrite.All",
            exempt_paths={"/healthz"},
        )
    return app
```

Add to `src/config.py`: `tenant_id`, `app_audience`, `entra_auth_enabled` (env‑driven, default off for local `pytest`/smoke). Add `python-jose[cryptography]` to `requirements.txt`.

> Local runs and the offline test suite keep `entra_auth_enabled=false`, so the 10 existing tests still pass unchanged. Only ACA sets it true.

---

## 5. Provision identity + infra (bicep, applied by azd)

The infra modules do four things. Review the generated `infra/`, then `azd provision`.

### 5a. Entra app registration + app role **[docs]** (`entra-app.bicep`)
Creates an app registration, sets the **identifier URI `api://<APP_CLIENT_ID>`**, and defines a custom **app role `Mcp.Tools.ReadWrite.All`** (allowed member type: application). Admin consent is granted for the tenant.

### 5b. Grant the app role to the Foundry project MI **[docs]** (`aif-role-assignment-entraapp.bicep`)
Assigns `Mcp.Tools.ReadWrite.All` on the app to `PROJECT_MI_OID` (from §2). This is the trust edge: only the project's managed identity can obtain a token our server will accept.

### 5c. ACA + managed identity (`aca-infrastructure.bicep`)
ACA environment + container app running our image, **external ingress**, `--target-port 8080`, `--min-replicas 1 --max-replicas 2` (prefer `1` over `0` so the first daily digest doesn't eat a cold start within the 100‑second tool timeout — drop to `0` only if idle cost matters more than first‑call latency). The app gets a **user‑assigned managed identity** used for Key Vault (§6).

### 5d. App Insights (`application-insights.bicep`)
`APPLICATIONINSIGHTS_CONNECTION_STRING` injected as an env var; OpenTelemetry traces flow with no code wiring, same as the agent.

```bash
source environment.sh          # exports TENANT_ID, APP_AUDIENCE (set post-5a), GS_*, IPE_*, etc.
azd provision                  # creates Entra app, role, role assignment, ACA env, KV, App Insights
```

> **Bump (expected):** `azd provision` may print the new `APP_CLIENT_ID` only after the app registration exists. Capture it, set `APP_AUDIENCE="api://<APP_CLIENT_ID>"` and `ENTRA_AUTH_ENABLED=true` in `environment.sh`, re‑`source`, then `azd deploy` (§7) picks them up as container env vars.

---

## 6. Secrets — Green Street client secret via Key Vault (not inline)

Outbound to Green Street is unchanged (OAuth2 client‑credentials); the change is **where the secret lives**. Store `GS_CLIENT_SECRET` in Key Vault and reference it from ACA via the container app's managed identity — never inline in `az`/bicep params, matching the security‑by‑design rule.

```bash
KV=kv-kohana-news                 # created by infra or pre-existing
az keyvault secret set --vault-name "$KV" -n gs-client-secret --value "$GS_CLIENT_SECRET"
# infra grants the container-app MI 'Key Vault Secrets User'; azure.yaml maps:
#   GS_CLIENT_SECRET  ->  secretref via KV reference
```

`GS_CLIENT_ID`, `GS_API_BASE`, `GS_TOKEN_URL`, `GS_DEFAULT_REGION`, `IPE_RSS_URLS`, `IPE_FULLTEXT_LICENSED=false`, `MCP_PORT`, `MCP_PATH` stay as plain env vars.

---

## 7. Build + deploy

```bash
azd deploy                        # ACR remote build (linux/amd64), push, ACA revision
FQDN=$(az containerapp show -g "$RG" -n kohana-news-mcp \
  --query properties.configuration.ingress.fqdn -o tsv)
echo "MCP endpoint: https://${FQDN}/mcp"
```

Or `azd up` to do provision + deploy in one shot on a clean environment.

---

## 8. Smoke‑test the raw MCP endpoint

Health probe is anonymous; the MCP path now requires a valid token, so unauthenticated `initialize` should be **rejected** (that's the pass condition for auth):

```bash
curl -s "https://${FQDN}/healthz"; echo                         # {"status":"ok",...}

# No token -> expect 401 (proves the middleware is live):
./scripts/smoke.sh "https://${FQDN}/mcp"                        # should show 401, not tools/list

# With a project-MI-scoped token, expect a real initialize + tools/list.  [confirm on run]
TOKEN=$(az account get-access-token --resource "api://<APP_CLIENT_ID>" --query accessToken -o tsv)
curl -s -X POST "https://${FQDN}/mcp" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"smoke","version":"0"}}}' | head -c 800; echo
```

> Your own `az` identity won't hold the app role (only the project MI does), so a token minted from your user may still 401 on the role check — that's correct. The authoritative end‑to‑end test is via the agent (§10), where the project MI is the caller.

---

## 9. Register in Toolbox v2 and promote (no agent redeploy) **[docs]**

The MI agent already consumes `kohana-mi-tools` via `FoundryToolbox(credential)`. Add the MCP as a `type: mcp` tool in a **new toolbox version**, test it on the **version‑specific endpoint**, then promote to the **consumer endpoint** the agent reads.

`mcp-toolbox-v2.yaml` (fill the FQDN, set the Entra connection):

```yaml
description: Kohana MI tools v2 — web grounding + Green Street + IPE
tools:
  - type: web_search
    name: web-search-default
    web_search:
      user_location: { city: Madrid, country: ES }
      search_context_size: medium

  - type: mcp
    server_label: kohana-news
    server_url: https://<FQDN>/mcp
    require_approval: never                 # all tools read-only
    # Entra auth: Microsoft Entra -> Project Managed Identity, audience = app URI
    authentication:
      type: microsoft_entra
      identity: project_managed_identity
      audience: api://<APP_CLIENT_ID>       # [confirm on run] exact field names
    allowed_tools:
      - greenstreet_search_articles
      - greenstreet_get_article
      - greenstreet_list_regions
      - greenstreet_list_sectors
      - ipe_latest_headlines
      - ipe_fulltext
      - provider_status
```

```bash
# Create as a NEW VERSION of the existing toolbox (do not overwrite v1):
azd ai toolbox create kohana-mi-tools --from-file mcp-toolbox-v2.yaml   # [confirm on run] verb/flags

# Consumer endpoint (promoted default, what the agent uses):
#   {project_endpoint}/toolboxes/kohana-mi-tools/mcp?api-version=v1
# Version endpoint (test BEFORE promoting):
#   {project_endpoint}/toolboxes/kohana-mi-tools/versions/<N>/mcp?api-version=v1
azd ai toolbox show kohana-mi-tools -o json    # read the version number + endpoints

# Test the version endpoint, then promote:
azd ai toolbox publish kohana-mi-tools <N>     # [confirm on run] promote-to-default verb
```

---

## 10. Verify end‑to‑end through the agent

No agent change, no redeploy — the promoted toolbox now exposes the news tools:

```bash
azd ai agent invoke market-intelligence \
  'Latest Green Street coverage of Spanish logistics assets — cite sources.'
azd ai agent invoke market-intelligence \
  'What paid sources are configured right now?'      # exercises provider_status
```

Expect the agent to call `greenstreet_search_articles` / `provider_status`, return the Deal/Price/Players/Trend structure with source links, and honestly report IPE as headline‑only and Iberinmo as pending. Trace the tool calls in App Insights.

---

## 11. Teardown

```bash
azd down --purge                              # ACA, ACR image, KV, App Insights, Entra app
# Toolbox: recreate/promote v1 to roll back the agent instantly if needed.
```

---

## Appendix A — Environment variables

| Variable | Who sets it | Purpose |
|---|---|---|
| `MCP_PORT` / `MCP_PATH` | env | Server bind + streamable‑HTTP mount (`8080` / `/mcp`). |
| `TENANT_ID` | env | Entra tenant for token issuer/JWKS. |
| `APP_CLIENT_ID` / `APP_AUDIENCE` | azd (post app‑reg) | `api://<APP_CLIENT_ID>` — the token audience the server validates. |
| `ENTRA_AUTH_ENABLED` | env | `true` in ACA, `false` for local/pytest/smoke. |
| `GS_CLIENT_ID` | env | Green Street client id (public). |
| `GS_CLIENT_SECRET` | **Key Vault → secretref** | GSN client secret; never inline. |
| `GS_API_BASE` / `GS_TOKEN_URL` / `GS_DEFAULT_REGION` | env | GSN endpoints + entitlement region. **[confirm on run]** token URL vs OpenAPI spec. |
| `IPE_RSS_URLS` / `IPE_FULLTEXT_LICENSED` | env | IPE feeds; full‑text stays `false` until written license. |
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | platform‑injected | OTel traces → App Insights. |

## Appendix B — Anticipated bumps → fixes

| Symptom | Cause | Fix |
|---|---|---|
| `initialize` returns tools/list with no token | auth middleware not mounted / `ENTRA_AUTH_ENABLED=false` in ACA | set env true; confirm `create_app` wraps the app |
| Agent tool calls 401 | project MI lacks the app role, or wrong audience | re‑run §5b role assignment; audience must equal `api://<APP_CLIENT_ID>` |
| `PROJECT_MI_OID` empty | identity on the account, not the project, or user‑assigned | inspect `identity` on both account and project |
| ACA revision won't start | image built for arm64 | build `--platform linux/amd64` |
| Session/stream errors under load or after scale‑down | stateful FastMCP on multi/zero replicas | `stateless_http=True`, `json_response=True` |
| First daily digest times out (~cold start) | `min-replicas 0` + 100s tool timeout | set `min-replicas 1` |
| `azd init --template azmcp-foundry-aca-mi` builds a .NET image | template ships Microsoft's Azure‑MCP server | repoint `azure.yaml` service at our Dockerfile; drop storage‑role module |
| GSN 401 on token fetch | wrong `GS_TOKEN_URL` | verify against `${GS_API_BASE}/docs?api-docs.json` |

## Appendix C — What we deliberately do NOT build

- No hand‑rolled `scripts/deploy.sh` / `az containerapp create` — infra is bicep applied by `azd` (mirrors the agent runbook's "don't hand‑write azure.yaml/infra").
- No public open MCP endpoint — Entra app + project‑MI trust is mandatory.
- No inline secrets — Key Vault + managed identity for `GS_CLIENT_SECRET`.
- No IPE full‑text retrieval and no Iberinmo integration — license/route not yet in place; `provider_status` reports the truth.
- No agent code change — integration is toolbox‑version promotion only.

## Appendix D — Kohana‑tenant hardening (post‑demo)

For the production tenant, tighten beyond the demo: **EU region** (`swedencentral` / `spaincentral` / `westeurope`) co‑located with the Foundry project per proposal §7/§9.4; and, if the MCP must be private, move to **Standard Agent Setup with private networking** — ACA **internal‑only ingress** on a **dedicated MCP subnet delegated to `Microsoft.App/environments`** (template `19-private-network-agents-tools-setup`), so the endpoint never faces the public internet while the same Entra trust and toolbox registration carry over unchanged.
