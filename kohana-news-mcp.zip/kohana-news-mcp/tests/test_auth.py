"""Offline tests for the Entra auth middleware — no network, no real tokens.

Verifies the two behaviours we can check without a live token:
  * /healthz is exempt and answers 200 anonymously (container probe),
  * the MCP path rejects an unauthenticated request with 401.
Full token validation (signature/audience/role) is exercised end-to-end via
the agent in the deployment runbook, not here.
"""
import asyncio
import os
import sys
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

_AUTH_ENV = {
    "ENTRA_AUTH_ENABLED": "true",
    "ENTRA_TENANT_ID": "00000000-0000-0000-0000-000000000000",
    "ENTRA_APP_AUDIENCE": "api://test-client-id",
}


def _fresh_server_with_auth():
    for m in ("server", "config", "greenstreet", "ipe", "auth"):
        sys.modules.pop(m, None)
    os.environ.update(_AUTH_ENV)
    import server  # noqa: WPS433 — reimport with auth enabled
    return server


def _teardown():
    for k in _AUTH_ENV:
        os.environ.pop(k, None)
    for m in ("server", "config", "greenstreet", "ipe", "auth"):
        sys.modules.pop(m, None)


def test_healthz_anonymous_and_mcp_requires_token():
    server = _fresh_server_with_auth()
    try:
        # The app is wrapped in EntraAuthMiddleware when auth is enabled.
        assert type(server.app).__name__ == "EntraAuthMiddleware"

        transport = httpx.ASGITransport(app=server.app)

        async def run():
            async with httpx.AsyncClient(transport=transport, base_url="http://t") as c:
                health = await c.get("/healthz")
                unauth = await c.post(
                    "/mcp",
                    json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
                )
                return health, unauth

        health, unauth = asyncio.run(run())
        assert health.status_code == 200
        assert health.json()["status"] == "ok"
        assert unauth.status_code == 401
        assert "unauthorized" in unauth.json()["error"]
    finally:
        _teardown()
