"""Offline tests for the Kohana News MCP server — no network, no credentials."""
import asyncio
import os
import sys
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


def _clean_env():
    for k in list(os.environ):
        if k.startswith(("GS_", "IPE_", "MCP_")):
            del os.environ[k]


# ------------------------------ config -------------------------------------

def test_defaults_and_configured_flag():
    _clean_env()
    from config import load_settings
    s = load_settings()
    assert s.gs_api_base == "https://web-news-service.greenstreet.com"
    assert s.gs_default_region == "EUR"
    assert s.greenstreet_configured is False
    assert s.ipe_fulltext_licensed is False
    assert len(s.ipe_rss_urls) == 1

    os.environ["GS_CLIENT_ID"] = "id"
    os.environ["GS_CLIENT_SECRET"] = "sec"
    os.environ["IPE_RSS_URLS"] = "https://a/x.rss, https://b/y.rss"
    s2 = load_settings()
    assert s2.greenstreet_configured is True
    assert s2.ipe_rss_urls == ["https://a/x.rss", "https://b/y.rss"]


# ------------------------------ IPE RSS ------------------------------------

RSS_SAMPLE = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel><title>IPE RA</title>
<item><title>Coima acquires Pirellino building in Milan for \u20ac175m</title>
<link>https://realassets.ipe.com/news/1</link>
<pubDate>Wed, 01 Jul 2026 09:00:00 GMT</pubDate>
<description>&lt;p&gt;Coima has &lt;b&gt;acquired&lt;/b&gt; the asset.&lt;/p&gt;</description></item>
<item><title>Madrid office asset sold</title>
<link>https://realassets.ipe.com/news/2</link>
<pubDate>Tue, 30 Jun 2026 09:00:00 GMT</pubDate>
<description>Middle Eastern investor pays for London office.</description></item>
</channel></rss>"""


def test_parse_rss_strips_html_and_maps_fields():
    from ipe import parse_rss
    items = parse_rss(RSS_SAMPLE, source_feed="feed1")
    assert len(items) == 2
    assert items[0].title.startswith("Coima acquires")
    assert items[0].link == "https://realassets.ipe.com/news/1"
    assert items[0].summary == "Coima has acquired the asset."
    assert items[0].source_feed == "feed1"


def test_ipe_latest_filters_keyword(monkeypatch):
    _clean_env()
    from config import load_settings
    from ipe import IPEClient

    client = IPEClient(load_settings())

    async def fake_get(url):
        return httpx.Response(200, text=RSS_SAMPLE, request=httpx.Request("GET", url))

    monkeypatch.setattr(client._http, "get", fake_get)
    items = asyncio.run(client.latest(keyword="madrid", limit=10))
    assert len(items) == 1 and "Madrid" in items[0]["title"]


def test_ipe_fulltext_gated_by_license():
    _clean_env()
    from config import load_settings
    from ipe import IPEClient
    res = asyncio.run(IPEClient(load_settings()).fetch_fulltext("https://x/1"))
    assert res["available"] is False
    assert "license" in res["reason"].lower()
    assert res["link"] == "https://x/1"


# --------------------------- Green Street client ----------------------------

class MockTransport(httpx.AsyncBaseTransport):
    """Route requests to canned responses; record calls."""

    def __init__(self):
        self.calls: list[httpx.Request] = []
        self.token_calls = 0

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        self.calls.append(request)
        url = str(request.url)
        if url.endswith("/oauth/token"):
            self.token_calls += 1
            return httpx.Response(200, json={"access_token": f"tok{self.token_calls}", "expires_in": 3600})
        if "/api/articles" in url and request.headers.get("authorization") == "Bearer tok1":
            return httpx.Response(200, json={"data": [{"id": 7, "title": "EUR deal"}]})
        if "/api/regions" in url:
            return httpx.Response(403)
        return httpx.Response(404)


def _gs_client(transport):
    _clean_env()
    os.environ.update({
        "GS_CLIENT_ID": "id", "GS_CLIENT_SECRET": "sec",
        "GS_TOKEN_URL": "https://my.gs.test/oauth/token",
        "GS_API_BASE": "https://gsn.test",
    })
    from config import load_settings
    from greenstreet import GreenStreetNewsClient
    c = GreenStreetNewsClient(load_settings())
    c._http = httpx.AsyncClient(transport=transport)
    return c


def test_gs_requires_credentials():
    _clean_env()
    from config import load_settings
    from greenstreet import GreenStreetNewsClient, GSNError
    with pytest.raises(GSNError, match="client-credentials"):
        GreenStreetNewsClient(load_settings())


def test_gs_search_authenticates_and_builds_query():
    t = MockTransport()
    c = _gs_client(t)
    res = asyncio.run(c.search_articles(region="EUR", keyword="logistics", sectors=[1, 3], page=2))
    assert res[0]["id"] == 7                        # {"data":[...]} is unwrapped
    assert t.token_calls == 1                      # token fetched once, cached
    q = str(t.calls[-1].url)
    assert "region=EUR" in q and "keyword=logistics" in q
    assert q.count("sectors=") == 2 and "page=2" in q   # repeated multi-select params


def test_gs_token_request_is_json_with_audience():
    import json as _json
    t = MockTransport()
    c = _gs_client(t)
    asyncio.run(c.search_articles(region="EUR"))
    token_reqs = [r for r in t.calls if str(r.url).endswith("/oauth/token")]
    assert len(token_reqs) == 1
    req = token_reqs[0]
    assert req.headers.get("content-type", "").startswith("application/json")
    body = _json.loads(req.content)
    assert body["grant_type"] == "client_credentials"
    assert body["audience"]                      # audience must be sent
    assert "user-agent" in {k.lower() for k in req.headers}


def test_gs_entitlement_error_is_explained():
    from greenstreet import GSNError
    t = MockTransport()
    c = _gs_client(t)
    with pytest.raises(GSNError, match="entitled"):
        asyncio.run(c.regions())


def test_gs_token_cached_across_calls():
    t = MockTransport()
    c = _gs_client(t)
    asyncio.run(c.search_articles(region="EUR"))
    asyncio.run(c.search_articles(region="EUR"))
    assert t.token_calls == 1


# ------------------------------ MCP surface ---------------------------------

def test_mcp_tools_registered_and_health_route():
    _clean_env()
    for m in ("server", "config", "greenstreet", "ipe"):
        sys.modules.pop(m, None)
    import server
    tool_names = asyncio.run(server.mcp.list_tools())
    names = {t.name for t in tool_names}
    assert {
        "greenstreet_search_articles", "greenstreet_get_article",
        "greenstreet_list_regions", "greenstreet_list_sectors",
        "greenstreet_list_topics", "greenstreet_list_asset_classes",
        "greenstreet_article_previews", "greenstreet_health",
        "ipe_latest_headlines", "ipe_fulltext", "provider_status",
    } <= names
    paths = {getattr(r, "path", None) for r in server.app.router.routes}
    assert "/healthz" in paths


def test_provider_status_reports_unconfigured_greenstreet():
    _clean_env()
    for m in ("server", "config", "greenstreet", "ipe"):
        sys.modules.pop(m, None)
    import server
    status = asyncio.run(server.provider_status())
    assert status["green_street"]["configured"] is False
    assert status["iberinmo_iberian_property"]["configured"] is False
    assert "license" in status["ipe_real_assets"]["mode"]
