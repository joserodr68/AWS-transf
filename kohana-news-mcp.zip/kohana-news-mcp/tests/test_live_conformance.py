"""LIVE conformance tests — the single command that verifies the real provider
contracts once credentials exist. Skipped automatically when they don't.

    GS_CLIENT_ID=... GS_CLIENT_SECRET=... GS_TOKEN_AUDIENCE=... \
    IPE_RSS_URLS=... pytest tests/test_live_conformance.py -v

What this proves against the LIVE APIs (the things offline mocks cannot):
  * the token endpoint/audience/body shape are accepted (auth actually works),
  * /api/health, /api/regions, /api/sectors respond with the assumed shapes,
  * an article search returns results for an entitled region,
  * the IPE feed URL is reachable and parses to headline/link/summary items.

Any failure here is the "adaptation to the provider's API" checklist: adjust
ONLY env values (GS_TOKEN_URL / GS_TOKEN_AUDIENCE / GS_API_BASE / IPE_RSS_URLS)
or the thin client methods in greenstreet.py, never the MCP/hosting layer.

Consistent with the offline suite: coroutines are driven with asyncio.run(),
so no pytest-asyncio plugin is required.
"""
import asyncio
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

_HAVE_GS = bool(os.getenv("GS_CLIENT_ID") and os.getenv("GS_CLIENT_SECRET"))


@pytest.mark.skipif(not _HAVE_GS, reason="live Green Street credentials not set")
def test_gs_token_and_core_endpoints_live():
    from config import load_settings
    from greenstreet import GreenStreetNewsClient

    async def run():
        c = GreenStreetNewsClient(load_settings())
        try:
            token = await c._bearer()            # auth must succeed end-to-end
            assert token and isinstance(token, str)

            health = await c.health()
            assert health.get("ok") is True

            regions = await c.regions()
            assert regions, "regions taxonomy came back empty"

            sectors = await c.sectors()
            assert sectors, "sectors taxonomy came back empty"

            region = os.getenv("GS_DEFAULT_REGION", "EUR")
            previews = await c.search_article_previews(region=region, page=1)
            assert previews is not None          # basic entitlement: should work
            articles = await c.search_articles(region=region, page=1)
            assert articles is not None
        finally:
            await c.aclose()

    asyncio.run(run())


@pytest.mark.skipif(not os.getenv("IPE_RSS_URLS"), reason="IPE_RSS_URLS not set")
def test_ipe_feed_reachable_and_parses_live():
    from config import load_settings
    from ipe import IPEClient

    async def run():
        c = IPEClient(load_settings())
        try:
            items = await c.latest(limit=5)
            real = [i for i in items if "_feed_errors" not in i]
            assert real, f"no IPE items parsed (errors: {items})"
            assert real[0]["title"] and real[0]["link"]
        finally:
            await c.aclose()

    asyncio.run(run())
