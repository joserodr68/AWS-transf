#!/usr/bin/env bash
# Post-deploy smoke test of the deployed MCP endpoint.
# With Entra auth ON, an UNAUTHENTICATED initialize must be rejected (401) and
# /healthz must answer 200 — that is the pass condition (proves auth is live).
# The authoritative tools/list check is via the agent (project MI as caller).
set -euo pipefail
URL="${1:?usage: smoke.sh https://<fqdn>/mcp}"
BASE="${URL%/mcp}"

echo "== /healthz (expect 200) =="
curl -s -o /dev/null -w "%{http_code}\n" "${BASE}/healthz"

echo "== /mcp initialize, no token (expect 401) =="
curl -s -o /dev/null -w "%{http_code}\n" -X POST "$URL" \
  -H "Content-Type: application/json" -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"smoke","version":"0"}}}'

echo "== optional: with a project-MI-scoped token (expect initialize result) =="
echo "TOKEN=\$(az account get-access-token --resource api://<APP_CLIENT_ID> --query accessToken -o tsv)"
echo "curl -s -X POST $URL -H \"Authorization: Bearer \$TOKEN\" ... "
