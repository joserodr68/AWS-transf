#!/usr/bin/env bash
# One-time Entra identity bootstrap for the News MCP (run BEFORE azd up).
# Creates the app registration + custom app role, then grants that role to the
# Foundry PROJECT managed identity — the only caller the server will accept.
# Entra objects are done via `az` (not bicep) on purpose: the Graph bicep
# extension is preview/fiddly, and these `az` calls are documented and stable.
#
# [confirm on run] app-role assignment for a managed identity uses the Graph
# appRoleAssignedTo endpoint; the `az rest` call below is the current shape.
set -euo pipefail
cd "$(dirname "$0")/.."
source environment.sh

: "${MCP_APP_NAME:?}"; : "${AZURE_TENANT_ID:?}"; : "${FOUNDRY_PROJECT_MI_OID:?set in environment.sh}"
ROLE="${ENTRA_REQUIRED_ROLE:-Mcp.Tools.ReadWrite.All}"
ROLE_ID=$(uuidgen)

echo "==> Create app registration + app role '$ROLE'"
APP_JSON=$(az ad app create --display-name "$MCP_APP_NAME" \
  --app-roles "[{\"allowedMemberTypes\":[\"Application\"],\"description\":\"Call the Kohana News MCP tools\",\"displayName\":\"$ROLE\",\"id\":\"$ROLE_ID\",\"isEnabled\":true,\"value\":\"$ROLE\"}]")
APP_CLIENT_ID=$(echo "$APP_JSON" | python -c "import sys,json;print(json.load(sys.stdin)['appId'])")
echo "APP_CLIENT_ID=$APP_CLIENT_ID"

echo "==> Set identifier URI api://$APP_CLIENT_ID"
az ad app update --id "$APP_CLIENT_ID" --identifier-uris "api://$APP_CLIENT_ID"

echo "==> Ensure a service principal exists for the app"
az ad sp create --id "$APP_CLIENT_ID" >/dev/null 2>&1 || true
SP_OID=$(az ad sp show --id "$APP_CLIENT_ID" --query id -o tsv)

echo "==> Grant the app role to the Foundry project managed identity"
az rest --method POST \
  --url "https://graph.microsoft.com/v1.0/servicePrincipals/${FOUNDRY_PROJECT_MI_OID}/appRoleAssignments" \
  --headers "Content-Type=application/json" \
  --body "{\"principalId\":\"${FOUNDRY_PROJECT_MI_OID}\",\"resourceId\":\"${SP_OID}\",\"appRoleId\":\"${ROLE_ID}\"}"

echo
echo "Done. Put these in environment.sh, then re-source and run 'azd up':"
echo "  export MCP_APP_CLIENT_ID=\"$APP_CLIENT_ID\""
echo "  export ENTRA_APP_AUDIENCE=\"api://$APP_CLIENT_ID\""
