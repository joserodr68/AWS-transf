"""Inbound authentication for the Kohana News MCP server.

The server sits behind an Entra app registration. The only caller we accept is
the Foundry project's managed identity, which has been granted the app role
``Mcp.Tools.ReadWrite.All`` on that app registration. Every request to the MCP
path must present a valid Entra access token whose:

  * signature verifies against the tenant JWKS,
  * ``aud`` equals api://<APP_CLIENT_ID>  (ENTRA_APP_AUDIENCE),
  * ``iss`` is the tenant v2.0 issuer,
  * ``roles`` contains ENTRA_REQUIRED_ROLE.

Anything else gets 401. ``/healthz`` is exempt so the Container Apps probe
stays anonymous. Auth is only mounted when ENTRA_AUTH_ENABLED=true, so local
runs and the offline test suite are unaffected.

NOTE [confirm on run]: pin the exact issuer once the app registration exists.
For a v2.0 token the issuer is https://login.microsoftonline.com/<tenant>/v2.0;
some managed-identity tokens use the sts.windows.net/<tenant>/ (v1.0) issuer.
Validate a real token from `az account get-access-token --resource <aud>` and
set the accepted issuer accordingly.
"""
from __future__ import annotations

import time

import httpx
from jose import jwt
from starlette.responses import JSONResponse


class EntraAuthMiddleware:
    """ASGI middleware validating Entra access tokens on the MCP path."""

    def __init__(self, app, tenant_id: str, audience: str, required_role: str,
                 exempt_paths: set[str] | None = None, jwks_ttl_s: int = 3600):
        if not tenant_id or not audience:
            raise ValueError(
                "EntraAuthMiddleware requires ENTRA_TENANT_ID and ENTRA_APP_AUDIENCE."
            )
        self.app = app
        self.audience = audience
        self.required_role = required_role
        self.exempt = exempt_paths or set()
        self.issuer = f"https://login.microsoftonline.com/{tenant_id}/v2.0"
        self.jwks_uri = f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"
        self._jwks: dict | None = None
        self._jwks_exp: float = 0.0
        self._jwks_ttl = jwks_ttl_s

    async def _keys(self) -> dict:
        if not self._jwks or time.time() > self._jwks_exp:
            async with httpx.AsyncClient(timeout=10) as c:
                self._jwks = (await c.get(self.jwks_uri)).json()
            self._jwks_exp = time.time() + self._jwks_ttl
        return self._jwks

    async def _reject(self, scope, receive, send, detail: str) -> None:
        resp = JSONResponse({"error": f"unauthorized: {detail}"}, status_code=401)
        await resp(scope, receive, send)

    async def __call__(self, scope, receive, send):
        # Pass through anything that isn't an HTTP request (e.g. lifespan) and
        # the exempt health probe.
        if scope.get("type") != "http" or scope.get("path") in self.exempt:
            return await self.app(scope, receive, send)

        headers = dict(scope.get("headers") or [])
        auth = headers.get(b"authorization", b"").decode()
        if not auth.lower().startswith("bearer "):
            return await self._reject(scope, receive, send, "missing bearer token")
        token = auth.split(" ", 1)[1].strip()

        try:
            claims = jwt.decode(
                token,
                await self._keys(),
                algorithms=["RS256"],
                audience=self.audience,
                issuer=self.issuer,
            )
        except Exception as exc:  # noqa: BLE001 — any failure is a 401
            return await self._reject(scope, receive, send, f"invalid token ({exc})")

        if self.required_role not in (claims.get("roles") or []):
            return await self._reject(scope, receive, send, "missing required app role")

        return await self.app(scope, receive, send)
