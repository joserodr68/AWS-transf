"""Green Street News API (GSN) client.

Implements the documented surface of the GSN API:
  * OAuth2 client-credentials → bearer token (client ID/secret generated at
    my.greenstreet.com/client-credentials; regional entitlements are enforced
    at the API gateway — requests for non-entitled regions are rejected).
  * GET /api/health                       — connectivity check
  * GET /api/regions                      — region taxonomy (parents + subregions)
  * GET /api/sectors                      — sector taxonomy
  * GET /api/articles                     — search (region required; optional
                                            keyword, sectors[], subregions[], page)
  * GET /api/articles/{id}                — full article

Endpoint paths/params follow the published docs; the authoritative contract is
the OpenAPI spec at {GS_API_BASE}/docs?api-docs.json — verify it once real
credentials exist (RUNBOOK V1) and adjust ONLY environment variables if the
token URL differs.

All requests are async httpx; the bearer token is cached until ~60s before
expiry and refreshed transparently. Errors are normalized to GSNError with
enough context for the agent to explain the problem to the user (e.g. a
missing regional entitlement) without leaking secrets.
"""
from __future__ import annotations

import time
from typing import Any

import httpx

from config import Settings


class GSNError(RuntimeError):
    """Normalized Green Street News API error (message is agent-safe)."""


class GreenStreetNewsClient:
    def __init__(self, settings: Settings):
        if not settings.greenstreet_configured:
            raise GSNError(
                "Green Street credentials not configured. Generate a client ID "
                "and secret at https://my.greenstreet.com/client-credentials "
                "and set GS_CLIENT_ID / GS_CLIENT_SECRET."
            )
        self._s = settings
        self._token: str | None = None
        self._token_exp: float = 0.0
        self._http = httpx.AsyncClient(
            timeout=settings.http_timeout_s,
            headers={"User-Agent": settings.user_agent},
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    # ---- auth -----------------------------------------------------------------

    async def _bearer(self) -> str:
        if self._token and time.monotonic() < self._token_exp - 60:
            return self._token
        # Green Street's token endpoint (Auth0-style) requires a JSON body with
        # an `audience`, and a User-Agent header (set on the client). Form-
        # encoding or a missing audience is rejected. See:
        #   https://login.greenstreet.com/oauth/token
        # [confirm on run] the `audience` for the NEWS service specifically —
        # the published example uses https://api.greenstreet.com; the exact
        # value for web-news-service is in {GS_API_BASE}/docs?api-docs.json.
        resp = await self._http.post(
            self._s.gs_token_url,
            json={
                "grant_type": "client_credentials",
                "client_id": self._s.gs_client_id,
                "client_secret": self._s.gs_client_secret,
                "audience": self._s.gs_token_audience,
            },
            headers={"Content-Type": "application/json"},
        )
        if resp.status_code != 200:
            raise GSNError(
                f"Green Street token request failed (HTTP {resp.status_code}). "
                "Check GS_TOKEN_URL against the OpenAPI spec and the validity "
                "of the client credentials."
            )
        payload = resp.json()
        self._token = payload.get("access_token")
        if not self._token:
            raise GSNError("Green Street token response contained no access_token.")
        self._token_exp = time.monotonic() + float(payload.get("expires_in", 3600))
        return self._token

    async def _get(self, path: str, params: Any = None) -> Any:
        token = await self._bearer()
        resp = await self._http.get(
            f"{self._s.gs_api_base}{path}",
            params=params,
            headers={"Authorization": f"Bearer {token}"},
        )
        if resp.status_code == 401:
            # Token may have been revoked server-side — retry once fresh.
            self._token = None
            token = await self._bearer()
            resp = await self._http.get(
                f"{self._s.gs_api_base}{path}",
                params=params,
                headers={"Authorization": f"Bearer {token}"},
            )
        if resp.status_code == 403:
            raise GSNError(
                "Green Street rejected the request: the token is not entitled "
                "to this region/product. Ask Kohana's account manager which "
                "regions the subscription covers."
            )
        if resp.status_code == 422:
            raise GSNError(f"Green Street validation error: {resp.text[:500]}")
        if resp.status_code == 424:
            raise GSNError("Green Street upstream dependency failed; retry later.")
        if resp.status_code == 503:
            raise GSNError("Green Street service temporarily unavailable; retry later.")
        if resp.status_code != 200:
            raise GSNError(f"Green Street API error (HTTP {resp.status_code}).")
        return resp.json()

    # ---- helpers ----------------------------------------------------------------

    @staticmethod
    def _unwrap(payload: Any) -> Any:
        """Every GSN JSON body is wrapped as {"data": ...}; return the inner
        value so tools hand the agent clean arrays/objects."""
        if isinstance(payload, dict) and "data" in payload:
            return payload["data"]
        return payload

    # ---- endpoints (reconciled to the live OpenAPI spec) -------------------------

    async def health(self) -> Any:
        """Connectivity check. GSN exposes /api/ping (entitlement: none)."""
        resp = await self._http.get(f"{self._s.gs_api_base}/api/ping")
        return {"status_code": resp.status_code, "ok": resp.status_code == 200}

    async def regions(self) -> Any:
        """Region taxonomy: id, parent, name, link. Items with parent=0 are the
        top-level regions (map to the alpha-3 codes ASA/AUS/CAN/EUR/USA/UK);
        children are usable as `subregions`. Requires product entitlements."""
        return self._unwrap(await self._get("/api/regions"))

    async def sectors(self) -> Any:
        """Sector taxonomy (id, name, link). Requires product entitlements."""
        return self._unwrap(await self._get("/api/sectors"))

    async def topics(self) -> Any:
        """Topic taxonomy (id, name, link) — usable as a `topics` filter."""
        return self._unwrap(await self._get("/api/topics"))

    async def asset_classes(self) -> Any:
        """Asset-class taxonomy (id, name, link) — usable as `asset_classes`."""
        return self._unwrap(await self._get("/api/asset-classes"))

    async def search_articles(
        self,
        region: str | None = None,
        keyword: str | None = None,
        sectors: list[int] | None = None,
        subregions: list[int] | None = None,
        asset_classes: list[int] | None = None,
        topics: list[int] | None = None,
        page: int = 1,
    ) -> Any:
        """Full article search (title, excerpt, taxonomy). `region` (alpha-3) is
        required; multi-select filters are repeated query params. Requires the
        region/product entitlements on the token (else 403). Prefer concise,
        single-term keywords. Returns the article list (data-unwrapped)."""
        params: list[tuple[str, Any]] = [
            ("region", region or self._s.gs_default_region),
            ("page", page),
        ]
        if keyword:
            params.append(("keyword", keyword))
        for sid in sectors or []:
            params.append(("sectors", sid))
        for sr in subregions or []:
            params.append(("subregions", sr))
        for ac in asset_classes or []:
            params.append(("asset_classes", ac))
        for tp in topics or []:
            params.append(("topics", tp))
        return self._unwrap(await self._get("/api/articles", params=params))

    async def search_article_previews(
        self,
        region: str | None = None,
        sectors: list[int] | None = None,
        subregions: list[int] | None = None,
        page: int = 1,
    ) -> Any:
        """Headline previews: id, title, gsNewsUrl, createdAt ONLY — no body,
        excerpt or taxonomy. Entitlement is `basic`: available to any
        authenticated GS user with no product entitlements. Best default for
        headline digests and the safe fallback before premium entitlements are
        provisioned. Returns the preview list (data-unwrapped)."""
        params: list[tuple[str, Any]] = [
            ("region", region or self._s.gs_default_region),
            ("page", page),
        ]
        for sid in sectors or []:
            params.append(("sectors", sid))
        for sr in subregions or []:
            params.append(("subregions", sr))
        return self._unwrap(await self._get("/api/articles-preview", params=params))

    async def get_article(self, article_id: int, region: str | None = None) -> Any:
        """Full article by id. The API REQUIRES a `region` (alpha-3) query
        param; it defaults to the configured entitlement region. Returns the
        article object (data-unwrapped), including `content`."""
        return self._unwrap(
            await self._get(
                f"/api/articles/{article_id}",
                params={"region": region or self._s.gs_default_region},
            )
        )
