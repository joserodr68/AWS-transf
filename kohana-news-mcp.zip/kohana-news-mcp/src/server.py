"""Kohana News MCP server — paid-subscription tools for the MI agent.

Exposes the providers as MCP tools over streamable HTTP so it can be
registered in the Foundry Toolbox (toolbox v2) as a `type: mcp` entry, or
consumed directly by MAF's MCPStreamableHTTPTool.

Transport: MCP streamable HTTP at $MCP_PATH (default /mcp) via the official
`mcp` Python SDK (FastMCP), in STATELESS mode (Azure Container Apps hosting is
stateless-only, and the app runs scale-to-zero / multi-replica). A plain GET
/healthz is added for container probes and left anonymous.

Inbound auth: when ENTRA_AUTH_ENABLED=true the app is wrapped in
EntraAuthMiddleware, which requires a valid Entra token carrying the
`Mcp.Tools.ReadWrite.All` app role (granted to the Foundry project's managed
identity). Off by default, so local runs and the offline tests need no tokens.

Tools (all read-only):
  greenstreet_health          — connectivity check against the GSN API
  greenstreet_list_regions    — region taxonomy (for filter values)
  greenstreet_list_sectors    — sector taxonomy
  greenstreet_search_articles — article search (region, keyword, sectors, page)
  greenstreet_get_article     — full article by id (subscription content —
                                for Kohana-internal use per Green Street terms)
  ipe_latest_headlines        — IPE Real Assets RSS: headline/summary/link only
  ipe_fulltext                — explains the licensing gate (returns link)
  provider_status             — what is configured/available right now

Design rules:
  * No provider portal usernames/passwords anywhere — Green Street uses the
    dedicated API client-credentials pair; IPE RSS needs no auth.
  * Compliance limits are enforced in code (IPE summary-only; Iberinmo absent
    until a compliant route exists), matching proposal §3.1/§4.
  * Tool outputs are JSON-serializable dicts; errors return {"error": ...}
    so the agent can explain problems instead of crashing the run.
"""
from __future__ import annotations

import logging
import os
from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from config import load_settings
from greenstreet import GreenStreetNewsClient, GSNError
from ipe import IPEClient

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("kohana-news-mcp")

settings = load_settings()

mcp = FastMCP(
    name="kohana-news",
    instructions=(
        "Paid real-estate news sources for Kohana Group. Use Green Street "
        "tools for European/UK commercial real estate news and IPE tools for "
        "institutional real-assets headlines. Always keep the article link "
        "in your answer so users can open sources with their subscription."
    ),
    host=settings.host,
    port=settings.port,
    streamable_http_path=settings.mcp_path,
    stateless_http=True,   # ACA MCP hosting is stateless; no per-replica sessions
    json_response=True,    # plain JSON responses (no SSE session channel)
)

# Lazily-created singletons (server may boot before credentials are set).
_gs: GreenStreetNewsClient | None = None
_ipe: IPEClient | None = None


def gs() -> GreenStreetNewsClient:
    global _gs
    if _gs is None:
        _gs = GreenStreetNewsClient(settings)  # raises GSNError if unconfigured
    return _gs


def ipe() -> IPEClient:
    global _ipe
    if _ipe is None:
        _ipe = IPEClient(settings)
    return _ipe


def _err(exc: Exception) -> dict[str, Any]:
    log.warning("tool error: %s", exc)
    return {"error": str(exc)}


# ---------------------------- Green Street tools ----------------------------

@mcp.tool()
async def greenstreet_health() -> dict:
    """Check connectivity to the Green Street News API."""
    try:
        return await gs().health()
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_list_regions() -> dict | list:
    """List Green Street regions (top-level, parent=0: e.g. EUR, UK, USA)
    and their subregions. Use these ids/codes to filter article searches."""
    try:
        return await gs().regions()
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_list_sectors() -> dict | list:
    """List Green Street sectors (office, retail, industrial, ...) with ids
    usable as article-search filters."""
    try:
        return await gs().sectors()
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_list_topics() -> dict | list:
    """List Green Street topics (id, name) usable as a `topics` search filter."""
    try:
        return await gs().topics()
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_list_asset_classes() -> dict | list:
    """List Green Street asset classes (id, name) usable as an `asset_classes`
    search filter."""
    try:
        return await gs().asset_classes()
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_article_previews(
    region: Annotated[str | None, Field(description="Region code, e.g. EUR or UK. Defaults to the configured region.")] = None,
    sectors: Annotated[list[int] | None, Field(description="Sector ids from greenstreet_list_sectors")] = None,
    subregions: Annotated[list[int] | None, Field(description="Subregion ids from greenstreet_list_regions")] = None,
    page: Annotated[int, Field(ge=1, description="Result page")] = 1,
) -> dict | list:
    """Latest Green Street headline PREVIEWS (title, link, date only — no body).
    Works for any authenticated user without premium product entitlements, so
    this is the best default for headline digests and the safe fallback when
    full article access isn't provisioned. Prefer this for 'daily digest'."""
    try:
        return await gs().search_article_previews(
            region=region, sectors=sectors, subregions=subregions, page=page
        )
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_search_articles(
    keyword: Annotated[str | None, Field(description="Concise single-term search keyword (docs recommend short terms)")] = None,
    region: Annotated[str | None, Field(description="Region code, e.g. EUR or UK. Defaults to the configured entitlement region.")] = None,
    sectors: Annotated[list[int] | None, Field(description="Sector ids from greenstreet_list_sectors")] = None,
    subregions: Annotated[list[int] | None, Field(description="Subregion ids from greenstreet_list_regions")] = None,
    asset_classes: Annotated[list[int] | None, Field(description="Asset-class ids from greenstreet_list_asset_classes")] = None,
    topics: Annotated[list[int] | None, Field(description="Topic ids from greenstreet_list_topics")] = None,
    page: Annotated[int, Field(ge=1, description="Result page (fixed page size upstream)")] = 1,
) -> dict | list:
    """Full Green Street News article search (titles, excerpts, metadata).
    Requires a region the Kohana token is entitled to; non-entitled regions are
    rejected by the gateway (use greenstreet_article_previews if so)."""
    try:
        return await gs().search_articles(
            region=region,
            keyword=keyword,
            sectors=sectors,
            subregions=subregions,
            asset_classes=asset_classes,
            topics=topics,
            page=page,
        )
    except GSNError as exc:
        return _err(exc)


@mcp.tool()
async def greenstreet_get_article(
    article_id: Annotated[int, Field(description="Article id from greenstreet_search_articles")],
    region: Annotated[str | None, Field(description="Region code (alpha-3) — REQUIRED by the API; defaults to the configured region.")] = None,
) -> dict:
    """Retrieve a full Green Street News article by id (requires a region).
    Content is Kohana's subscription material — summarize for internal use and
    cite the link."""
    try:
        return await gs().get_article(article_id, region=region)
    except GSNError as exc:
        return _err(exc)


# ------------------------------- IPE tools ---------------------------------

@mcp.tool()
async def ipe_latest_headlines(
    keyword: Annotated[str | None, Field(description="Optional case-insensitive filter over title+summary")] = None,
    limit: Annotated[int, Field(ge=1, le=50, description="Max items")] = 20,
) -> list:
    """Latest IPE Real Assets headlines from RSS (includes PropertyEU).
    Returns headline, feed summary, link, date — NOT full text (licensing)."""
    try:
        return await ipe().latest(keyword=keyword, limit=limit)
    except Exception as exc:  # noqa: BLE001
        return [_err(exc)]


@mcp.tool()
async def ipe_fulltext(
    link: Annotated[str, Field(description="Article link from ipe_latest_headlines")],
) -> dict:
    """Explain the IPE full-text availability for an article. Until a written
    license is in place this returns the compliance explanation + link."""
    return await ipe().fetch_fulltext(link)


# ------------------------------ Meta tool ----------------------------------

@mcp.tool()
async def provider_status() -> dict:
    """Report which paid providers are configured and how they are integrated.
    Useful for the agent to explain data coverage honestly."""
    return {
        "green_street": {
            "configured": settings.greenstreet_configured,
            "mode": "official News API (client credentials)",
            "default_region": settings.gs_default_region,
            "api_base": settings.gs_api_base,
        },
        "ipe_real_assets": {
            "configured": bool(settings.ipe_rss_urls),
            "mode": "RSS headlines/summaries + link (full text pending written license)",
            "feeds": settings.ipe_rss_urls,
            "fulltext_licensed": settings.ipe_fulltext_licensed,
        },
        "iberinmo_iberian_property": {
            "configured": False,
            "mode": (
                "no API/RSS available; pending syndication agreement — "
                "interim plan: newsletter ingestion via Microsoft Graph"
            ),
        },
    }


# ------------------------------ Entrypoint ---------------------------------

def create_app():
    """ASGI app: FastMCP streamable-HTTP app + anonymous /healthz probe,
    optionally wrapped in Entra token validation (ENTRA_AUTH_ENABLED)."""
    app = mcp.streamable_http_app()

    from starlette.requests import Request
    from starlette.responses import JSONResponse
    from starlette.routing import Route

    async def healthz_endpoint(request: Request):
        return JSONResponse({"status": "ok", "server": "kohana-news-mcp"})

    app.router.routes.append(Route("/healthz", healthz_endpoint, methods=["GET"]))

    if settings.entra_auth_enabled:
        from auth import EntraAuthMiddleware
        return EntraAuthMiddleware(
            app,
            tenant_id=settings.entra_tenant_id,
            audience=settings.entra_app_audience,
            required_role=settings.entra_required_role,
            exempt_paths={"/healthz"},
        )
    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn

    log.info("Kohana News MCP on %s:%s%s (entra_auth=%s)",
             settings.host, settings.port, settings.mcp_path, settings.entra_auth_enabled)
    uvicorn.run(app, host=settings.host, port=settings.port)
