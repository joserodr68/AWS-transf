"""IPE Real Assets — RSS ingestion (compliance-limited).

IPE offers RSS feeds in XML; there is no public content API. Their terms
permit feed consumption but reserve reproduction/reuse rights, so this module
returns ONLY headline, summary/description as provided in the feed, link,
date and source — never scraped full text — unless IPE_FULLTEXT_LICENSED is
set after a written license is obtained (the hook exists but full-text
retrieval is intentionally NOT implemented until that day; see fetch_fulltext).

PropertyEU content is integrated into the IPE Real Assets site, so these
feeds cover both brands.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass

import httpx

from config import Settings


@dataclass
class FeedItem:
    title: str
    link: str
    published: str
    summary: str
    source_feed: str


class IPEClient:
    def __init__(self, settings: Settings):
        self._s = settings
        self._http = httpx.AsyncClient(
            timeout=settings.http_timeout_s,
            headers={"User-Agent": settings.user_agent},
            follow_redirects=True,
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    async def latest(self, keyword: str | None = None, limit: int = 20) -> list[dict]:
        """Fetch and merge all configured feeds, newest first (feed order),
        optionally filtered by a case-insensitive keyword over title+summary."""
        items: list[FeedItem] = []
        errors: list[str] = []
        for url in self._s.ipe_rss_urls:
            try:
                resp = await self._http.get(url)
                resp.raise_for_status()
                items.extend(parse_rss(resp.text, source_feed=url))
            except Exception as exc:  # noqa: BLE001 — surfaced to the agent
                errors.append(f"{url}: {type(exc).__name__}")
        if keyword:
            k = keyword.lower()
            items = [i for i in items if k in i.title.lower() or k in i.summary.lower()]
        result = [asdict(i) for i in items[:limit]]
        if errors:
            # Non-fatal: return what we have plus a note the agent can relay.
            return [{"_feed_errors": errors}] + result
        return result

    async def fetch_fulltext(self, link: str) -> dict:
        """Full-text retrieval is gated behind the written IPE license.

        Deliberately NOT implemented even when the flag is on until the
        license terms (allowed fields, retention, attribution) are known —
        the flag only changes the message so the agent explains the state
        truthfully.
        """
        if not self._s.ipe_fulltext_licensed:
            return {
                "available": False,
                "reason": (
                    "Full-text use of IPE content requires a written license "
                    "from IPE International Publishers. Headline, summary and "
                    "link are available; open the article with Kohana's "
                    "subscription for the full text."
                ),
                "link": link,
            }
        return {
            "available": False,
            "reason": (
                "License flag is set but the licensed retrieval path has not "
                "been implemented/configured yet. Contact the platform team."
            ),
            "link": link,
        }


def parse_rss(xml_text: str, source_feed: str) -> list[FeedItem]:
    """Minimal, dependency-free RSS 2.0 / Atom parser for the fields we may use."""
    root = ET.fromstring(xml_text)
    items: list[FeedItem] = []

    # RSS 2.0: <rss><channel><item>
    for item in root.iter("item"):
        items.append(
            FeedItem(
                title=_text(item, "title"),
                link=_text(item, "link"),
                published=_text(item, "pubDate"),
                summary=_strip_html(_text(item, "description")),
                source_feed=source_feed,
            )
        )
    if items:
        return items

    # Atom: <feed><entry>
    ns = {"a": "http://www.w3.org/2005/Atom"}
    for entry in root.findall("a:entry", ns):
        link_el = entry.find("a:link", ns)
        items.append(
            FeedItem(
                title=_text_ns(entry, "a:title", ns),
                link=link_el.get("href", "") if link_el is not None else "",
                published=_text_ns(entry, "a:updated", ns) or _text_ns(entry, "a:published", ns),
                summary=_strip_html(_text_ns(entry, "a:summary", ns)),
                source_feed=source_feed,
            )
        )
    return items


def _text(el: ET.Element, tag: str) -> str:
    child = el.find(tag)
    return (child.text or "").strip() if child is not None else ""


def _text_ns(el: ET.Element, tag: str, ns: dict) -> str:
    child = el.find(tag, ns)
    return (child.text or "").strip() if child is not None else ""


def _strip_html(text: str) -> str:
    """Cheap tag removal for feed descriptions (no external deps)."""
    out, in_tag = [], False
    for ch in text:
        if ch == "<":
            in_tag = True
        elif ch == ">":
            in_tag = False
        elif not in_tag:
            out.append(ch)
    return "".join(out).strip()
