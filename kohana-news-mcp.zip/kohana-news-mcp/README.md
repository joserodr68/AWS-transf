# Kohana News MCP

A standalone remote **MCP server** exposing Kohana Group's paid real-estate
news subscriptions as read-only tools for the Market Intelligence agent (M1).
Built with the official MCP Python SDK (FastMCP) over streamable HTTP, hosted
on **Azure Container Apps**, secured with an **Entra app registration** whose
`Mcp.Tools.ReadWrite.All` role is granted to the **Foundry project managed
identity**, and surfaced to the agent by registering it in the existing
`kohana-mi-tools` **Toolbox as a new version** — no agent code change, no
redeploy.

Companion to the M1 agent; same discipline as `mi-agent-clean`: the repo holds
only the source you own, and the Azure infra is scaffolded per target project.

## Providers

| Provider | Integration | Compliance boundary |
|---|---|---|
| **Green Street News API** | Official API, OAuth2 client-credentials (secret in Key Vault) | Regional entitlements enforced at the GSN gateway; no portal credentials |
| **IPE Real Assets** (incl. PropertyEU) | RSS: headline, summary, link, date | Full text **gated** behind `IPE_FULLTEXT_LICENSED` until a written license exists |
| **Iberinmo / Iberian Property** | Status stub | No compliant API/RSS route yet; `provider_status` reports this honestly |

## Tools (all read-only)

`greenstreet_health`, `greenstreet_list_regions`, `greenstreet_list_sectors`,
`greenstreet_list_topics`, `greenstreet_list_asset_classes`,
`greenstreet_article_previews` (basic entitlement — headline/date/link),
`greenstreet_search_articles`, `greenstreet_get_article`,
`ipe_latest_headlines`, `ipe_fulltext`, `provider_status`.

Green Street endpoints are reconciled to the live OpenAPI spec
(`web-news-service.greenstreet.com/docs?api-docs.json`): health is `/api/ping`,
responses are `{"data": …}`-unwrapped, `get_article` sends the required
`region`, and `article-previews` (open to any authenticated user, no premium
entitlement) is the digest default and the fallback before entitlements land.

## Layout

```
src/
  server.py        FastMCP server (stateless_http; anonymous /healthz; auth-wired)
  config.py        env-driven settings (server, Entra, Green Street, IPE)
  auth.py          Entra bearer-token validation middleware
  greenstreet.py   Green Street News API client (OAuth2, token cache, error mapping)
  ipe.py           IPE RSS client (dependency-free parser; full-text gated)
tests/             11 offline tests — no network, no credentials, no tokens
scripts/
  setup-entra.sh   one-time: app registration + role + project-MI grant
  smoke.sh         post-deploy: /healthz 200, unauthenticated /mcp 401
Dockerfile         python:3.13-slim, linux/amd64
mcp-toolbox-v2.yaml  Toolbox v2 registration (web_search + this MCP)
environment.sh.example  parametrization (copy to environment.sh, gitignored)
INIT.md            short deploy path per target project
MCP_DEPLOYMENT_RUNBOOK.md  full step-by-step + bumps→fixes
```

`azure.yaml` and `infra/` are **not** committed — they are scaffolded per
project (`azd`) and gitignored, so the same source deploys cleanly to the demo
account and later to Kohana's tenant.

## Quick start (local, no cloud)

```bash
cp environment.sh.example environment.sh && source environment.sh
python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt pytest
pytest -q                      # 11 passed
(cd src && python server.py)   # http://localhost:8080  → GET /healthz = 200
```

Auth is **disabled locally** (`ENTRA_AUTH_ENABLED=false`) so the server and the
test suite run without tokens; it is enabled only in Container Apps. Deploy
steps: see `INIT.md`, full detail in `MCP_DEPLOYMENT_RUNBOOK.md`.

## Design principles

- **No secrets in repo or image** — Green Street secret via Key Vault + managed
  identity; nothing baked into the container.
- **Compliance enforced in code**, not just docs — IPE full-text gated,
  Iberinmo absent until a lawful route exists.
- **Fail informative, not fatal** — tool errors return `{"error": ...}` the
  agent can explain (e.g. a missing regional entitlement).
- **Stateless, secured, self-contained** — stateless HTTP for scale-to-zero;
  Entra + project-MI trust; deployable to any target project from clean source.
```
