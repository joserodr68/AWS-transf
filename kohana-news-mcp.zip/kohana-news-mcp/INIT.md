# INIT — deploy this MCP server against a target Foundry project

This repo contains **only the source you own**: the MCP server (`src/`), its
Dockerfile, the toolbox-v2 registration, and the identity/deploy scripts. The
Azure infra (`azure.yaml`, `infra/`) is **scaffolded per project** and
gitignored, because it hard-codes a specific project/registry/Key Vault — so
it is regenerated for each target (demo account, then Kohana's tenant).

Full detail and the bumps→fixes table live in `MCP_DEPLOYMENT_RUNBOOK.md`.
This is the short path.

## 0. Prereqs
azd ≥ 1.27, `az` logged in, Contributor on the RG, Application Administrator
in Entra, Azure AI Administrator on the project. (Same base as the M1 agent.)

## 1. Identifiers of the TARGET project
```bash
RG=<resource-group>            # e.g. rg-joserodr72t-8090
ACCT=<foundry-account>         # e.g. joserodr72t-8090-resource
PROJ=<foundry-project>         # e.g. joserodr72t-8090
PROJECT_ID=$(az resource show -g "$RG" --namespace Microsoft.CognitiveServices \
  --parent accounts/"$ACCT" --resource-type projects -n "$PROJ" --query id -o tsv)
PROJECT_MI_OID=$(az resource show --ids "$PROJECT_ID" --query identity.principalId -o tsv)
```
Put `PROJECT_ID` / `PROJECT_MI_OID` into `environment.sh` (see the `.example`).

## 2. Local verification (no cloud, no tokens)
```bash
cp environment.sh.example environment.sh && vi environment.sh && source environment.sh
python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt pytest
pytest -q                                  # 11/11 offline (auth disabled locally)
(cd src && python server.py)               # boots; curl localhost:8080/healthz -> 200
```

## 3. Entra identity bootstrap (one-time)
```bash
./scripts/setup-entra.sh                    # app reg + Mcp.Tools.ReadWrite.All role
# copy the printed MCP_APP_CLIENT_ID / ENTRA_APP_AUDIENCE into environment.sh, re-source
```

## 4. Scaffold infra + deploy to Azure Container Apps
```bash
azd init --template azmcp-foundry-aca-mi -e kohana-news-mcp-dev   # infra modules only
#  -> repoint azure.yaml's service at THIS repo's Dockerfile; drop storage-role module
az keyvault secret set --vault-name "$MCP_KEYVAULT_NAME" -n gs-client-secret --value "<secret>"
azd up                                       # provision (ACA+KV+App Insights) + deploy
FQDN=$(az containerapp show -g "$MCP_RESOURCE_GROUP" -n "$MCP_APP_NAME" \
  --query properties.configuration.ingress.fqdn -o tsv)
./scripts/smoke.sh "https://${FQDN}/mcp"     # healthz 200, unauth /mcp 401
```

## 5. Register in Toolbox v2 and promote (no agent redeploy)
```bash
sed -i "s|<FQDN>|$FQDN|; s|<APP_CLIENT_ID>|$MCP_APP_CLIENT_ID|" mcp-toolbox-v2.yaml
azd ai toolbox create kohana-mi-tools --from-file mcp-toolbox-v2.yaml   # NEW version
azd ai toolbox show   kohana-mi-tools -o json      # read version N + endpoints
# test the version endpoint, then promote:
azd ai toolbox publish kohana-mi-tools <N>
```

## 6. Verify through the agent
```bash
azd ai agent invoke market-intelligence \
  'Latest Green Street coverage of Spanish logistics — cite sources.'
azd ai agent invoke market-intelligence 'What paid sources are configured now?'
```

## Teardown
```bash
azd down --purge
az ad app delete --id "$MCP_APP_CLIENT_ID"
```
